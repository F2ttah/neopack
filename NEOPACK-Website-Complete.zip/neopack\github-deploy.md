# دليل نشر NEOPACK على GitHub Pages

## 🚀 النشر السريع على GitHub

### الخطوة 1: إنشاء Repository

1. **اذهب إلى [github.com](https://github.com)**
2. **اضغط على زر "+" في الأعلى**
3. **اختر "New repository"**
4. **أدخل اسم Repository: `neopack`**
5. **اختر "Public"**
6. **اضغط "Create repository"**

### الخطوة 2: رفع الملفات

#### الطريقة الأولى: عبر GitHub Web Interface

1. **في repository الجديد، اضغط "uploading an existing file"**
2. **اسحب جميع الملفات من مجلد `neopack` إلى GitHub:**
   ```
   ✅ index.html
   ✅ styles.css
   ✅ script.js
   ✅ README.md
   ✅ .gitignore
   ✅ LICENSE
   ✅ deploy-guide.md
   ✅ github-deploy.md
   ✅ images/favicon.svg
   ✅ images/logo-placeholder.svg
   ```
3. **اكتب رسالة commit:**
   ```
   Initial commit - NEOPACK Website
   
   - متجر الأكواب المخصصة بالذكاء الاصطناعي
   - مصمم AI لتصميم الأكواب
   - تصميم متجاوب ومحسن SEO
   - جاهز للنشر على GitHub Pages
   ```
4. **اضغط "Commit changes"**

#### الطريقة الثانية: عبر Git CLI

```bash
# في مجلد neopack
git init
git add .
git commit -m "Initial commit - NEOPACK Website"
git branch -M main
git remote add origin https://github.com/USERNAME/neopack.git
git push -u origin main
```

### الخطوة 3: تفعيل GitHub Pages

1. **في repository، اذهب إلى "Settings"**
2. **اضغط "Pages" في القائمة الجانبية**
3. **في "Source"، اختر "Deploy from a branch"**
4. **في "Branch"، اختر "main" و "/(root)"**
5. **اضغط "Save"**
6. **انتظر 2-5 دقائق**

### الخطوة 4: الوصول للموقع

الرابط سيكون: `https://USERNAME.github.io/neopack`

## 📁 هيكل الملفات المطلوب

```
neopack/
├── index.html              # الصفحة الرئيسية
├── styles.css              # ملف التصميم
├── script.js               # ملف JavaScript
├── images/                 # مجلد الصور
│   ├── favicon.svg         # أيقونة الموقع
│   └── logo-placeholder.svg # شعار مؤقت
├── README.md               # ملف التوثيق
├── .gitignore              # ملف Git
├── LICENSE                 # رخصة المشروع
├── deploy-guide.md         # دليل النشر العام
└── github-deploy.md        # هذا الملف
```

## 🔧 إعدادات متقدمة

### إضافة نطاق مخصص:

1. **اشتر نطاق من أي مزود**
2. **في GitHub Pages Settings، أضف النطاق**
3. **أضف ملف CNAME في repository:**
   ```
   yourdomain.com
   ```
4. **أضف DNS records في مزود النطاق**

### تحسين SEO:

1. **أضف Google Analytics:**
   ```html
   <!-- في head -->
   <script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
   <script>
     window.dataLayer = window.dataLayer || [];
     function gtag(){dataLayer.push(arguments);}
     gtag('js', new Date());
     gtag('config', 'GA_MEASUREMENT_ID');
   </script>
   ```

2. **أضف Google Search Console:**
   - اذهب إلى [search.google.com](https://search.google.com)
   - أضف موقعك
   - تحقق من الملكية

### إضافة ملف 404 مخصص:

أنشئ ملف `404.html` في المجلد الجذر:

```html
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الصفحة غير موجودة - NEOPACK</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container" style="text-align: center; padding: 100px 20px;">
        <h1>404</h1>
        <h2>الصفحة غير موجودة</h2>
        <p>عذراً، الصفحة التي تبحث عنها غير موجودة.</p>
        <a href="/" class="cta-button primary">العودة للصفحة الرئيسية</a>
    </div>
</body>
</html>
```

## 🚨 استكشاف الأخطاء

### المشكلة: الموقع لا يظهر
**الحل:**
1. تأكد من أن Repository عام (Public)
2. انتظر 5-10 دقائق
3. تحقق من إعدادات GitHub Pages
4. امسح cache المتصفح

### المشكلة: الصور لا تظهر
**الحل:**
1. تأكد من صحة مسارات الصور
2. تأكد من وجود مجلد `images/`
3. تحقق من أسماء الملفات

### المشكلة: التصميم لا يعمل
**الحل:**
1. تأكد من وجود `styles.css`
2. تحقق من console المتصفح
3. تأكد من تحميل الملفات

### المشكلة: JavaScript لا يعمل
**الحل:**
1. تأكد من وجود `script.js`
2. تحقق من console المتصفح
3. تأكد من عدم وجود أخطاء في الكود

## 📊 مراقبة الأداء

### أدوات مجانية:
1. **Google PageSpeed Insights**
2. **GTmetrix**
3. **WebPageTest**

### تحسينات مقترحة:
1. **ضغط الصور**
2. **تفعيل Gzip**
3. **استخدام CDN**
4. **تحسين CSS/JS**

## 🔒 الأمان

### إعدادات أمان أساسية:
1. **HTTPS إجباري** (تلقائي في GitHub Pages)
2. **Security Headers**
3. **Content Security Policy**

### إضافة ملف robots.txt:

أنشئ ملف `robots.txt` في المجلد الجذر:

```
User-agent: *
Allow: /

Sitemap: https://USERNAME.github.io/neopack/sitemap.xml
```

### إضافة ملف sitemap.xml:

أنشئ ملف `sitemap.xml` في المجلد الجذر:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://USERNAME.github.io/neopack/</loc>
    <lastmod>2024-01-01</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>
```

## 📱 إضافة إلى الشاشة الرئيسية

### على الهاتف:
1. افتح الموقع في Chrome
2. اضغط على القائمة (⋮)
3. اختر "إضافة إلى الشاشة الرئيسية"

### على الكمبيوتر:
1. افتح الموقع في Chrome
2. اضغط Ctrl+Shift+I
3. اضغط على أيقونة الهاتف
4. اختر "Add to Home Screen"

## 🎨 إضافة الشعار الحقيقي

### لإضافة شعار NEOPACK الحقيقي:

1. **ضع ملف الشعار في مجلد `images/`:**
   ```
   neopack/
   ├── images/
   │   ├── logo.png          # شعار NEOPACK
   │   ├── logo-white.png    # شعار أبيض للخلفيات الداكنة
   │   ├── favicon.svg       # أيقونة الموقع (جاهزة)
   │   └── favicon.ico       # أيقونة الموقع
   ```

2. **أحجام الشعار الموصى بها:**
   - **الشعار الرئيسي**: 200x80px (PNG مع خلفية شفافة)
   - **الشعار الأبيض**: 200x80px (للخلفيات الداكنة)
   - **أيقونة الموقع**: 32x32px (جاهزة)

3. **تنسيقات مدعومة:**
   - PNG (مفضل للشعارات)
   - JPG (للصور)
   - SVG (للشعارات المتجهية)
   - ICO (لأيقونة الموقع)

## 📞 الدعم

### إذا واجهت مشكلة:
1. **تحقق من console المتصفح**
2. **راجع ملفات Log**
3. **تواصل مع الدعم الفني**

### روابط مفيدة:
- [GitHub Pages Help](https://help.github.com/en/github/working-with-github-pages)
- [GitHub Support](https://support.github.com/)
- [GitHub Community](https://github.community/)

## 🎯 الخطوات النهائية

بعد النشر:
1. ✅ **اختبر الموقع على الهاتف**
2. ✅ **اختبر مصمم AI**
3. ✅ **اختبر نموذج الطلب**
4. ✅ **اختبر مساعد AI**
5. ✅ **شارك الرابط مع العملاء**

## 📈 تحسينات إضافية

### إضافة Google Analytics:
1. اذهب إلى [analytics.google.com](https://analytics.google.com)
2. أنشئ حساب جديد
3. أضف الموقع
4. احصل على ID
5. أضف الكود في `index.html`

### إضافة Facebook Pixel:
1. اذهب إلى [business.facebook.com](https://business.facebook.com)
2. أنشئ Pixel جديد
3. أضف الكود في `index.html`

### إضافة WhatsApp Business:
1. اذهب إلى [business.whatsapp.com](https://business.whatsapp.com)
2. أنشئ حساب Business
3. احصل على رقم WhatsApp Business
4. أضف الرقم في الموقع

---

**مبروك! موقع NEOPACK جاهز للعمل على GitHub Pages! 🎉** 